-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 03-Fev-2023 às 03:28
-- Versão do servidor: 10.4.20-MariaDB
-- versão do PHP: 8.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `pdv`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `cliente`
--

CREATE TABLE `cliente` (
  `id` int(5) NOT NULL,
  `nome` varchar(90) NOT NULL,
  `tipo_pessoa` varchar(2) NOT NULL,
  `cpf` varchar(45) DEFAULT NULL,
  `cnpj` varchar(45) DEFAULT NULL,
  `email` varchar(45) NOT NULL,
  `fone_1` varchar(45) NOT NULL,
  `fone_2` varchar(45) DEFAULT NULL,
  `fone_3` varchar(45) DEFAULT NULL,
  `rua` varchar(90) NOT NULL,
  `numero` int(5) NOT NULL,
  `bairro` varchar(90) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `cliente`
--

INSERT INTO `cliente` (`id`, `nome`, `tipo_pessoa`, `cpf`, `cnpj`, `email`, `fone_1`, `fone_2`, `fone_3`, `rua`, `numero`, `bairro`) VALUES
(5, 'JOAO', 'PF', '123.456.789-89', '  .   .   /    -  ', 'JOAO@HOTMAIL.COM', '(34)99782-6548', '(  )     -    ', '(  )     -    ', 'ITAPAGIPE', 7941, 'PROGRESSO'),
(6, 'LUCAS', 'PJ', '   .   .   -  ', '12.121.212/1212-12', 'LUCAS@HOTMAIL.COM', '(34)99778-9878', '(34)99534-6589', '(  )     -    ', 'AV GOIAS', 1200, 'NOSSA SENHORA');

-- --------------------------------------------------------

--
-- Estrutura da tabela `funcionario`
--

CREATE TABLE `funcionario` (
  `id` int(5) NOT NULL,
  `nome` varchar(90) NOT NULL,
  `num_carteira` varchar(45) NOT NULL,
  `funcao` varchar(45) NOT NULL,
  `fone` varchar(45) NOT NULL,
  `email` varchar(90) NOT NULL,
  `senha` int(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `funcionario`
--

INSERT INTO `funcionario` (`id`, `nome`, `num_carteira`, `funcao`, `fone`, `email`, `senha`) VALUES
(2, 'JOAO PEDRO', '1234567899-8', 'OPERADOR', '(34)99775-2030', 'JOAO@HOTMAIL.COM', 12345678),
(3, 'LUCAS', '7887878787-8', 'VENDEDOR', '(34)99797-9797', 'LUCAS@HOTMAIL.COM', 102030),
(5, 'TESTE', '1111111111-1', 'OPERADOR', '(11)11111-1111', 'TESTE@HOTMAIL.COM', 1234),
(6, 'TESTE2', '2222222222-2', 'VENDEDOR', '(33)33333-3333', 'TESTE2@GMAIL.COM', 1020),
(7, 'LEONARDO', '1020304050-0', 'OPERADOR', '(97)99797-9797', 'LEONARDO@HOTMAIL.COM', 123456),
(8, 'MARIO', '1222125555-5', 'OPERADOR', '(34)99999-9999', 'MARIO@GMAIL.COM', 12345),
(9, 'TESTE3', '4444444444-4', 'OPERADOR', '(79)99999-9999', 'TESTE@HOTMAIL.COM', 12345),
(10, 'MARCOS', '4444444444-4', 'OPERADOR', '(34)99787-7532', 'MARCOS@HOTMAIL.COM', 54321),
(11, 'ELTON', '1111111111-1', 'VENDEDOR', '(89)99999-9999', 'ELTON@HOTMAIL.COM', 12356),
(13, 'RAFAELA ', '9656555555-5', 'VENDEDORA', '(22)22222-2222', 'RAFA@HOTMAIL.COM', 1234);

-- --------------------------------------------------------

--
-- Estrutura da tabela `produto`
--

CREATE TABLE `produto` (
  `id` int(5) NOT NULL,
  `nome` varchar(45) NOT NULL,
  `marca` varchar(45) NOT NULL,
  `categoria` varchar(45) NOT NULL,
  `descricao` varchar(255) DEFAULT NULL,
  `vl_custo` double NOT NULL,
  `vl_venda` double NOT NULL,
  `estoque` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `produto`
--

INSERT INTO `produto` (`id`, `nome`, `marca`, `categoria`, `descricao`, `vl_custo`, `vl_venda`, `estoque`) VALUES
(1, 'PARAFUSO DE RODA PARA FIAT UNO', 'FIAT', 'PARAFUSO', 'PARAFUSO DE RODA PARA FIAT UNO ANO 90 A 00 N6', 5, 8, 60),
(3, 'PNEU F800 FORD', 'FORD', 'PNEU', 'PNEU PARA FORD F800 ANOS 70 A 79', 40.99, 50.99, 30);

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuario`
--

CREATE TABLE `usuario` (
  `id_usuario` int(5) DEFAULT NULL,
  `email` varchar(90) DEFAULT NULL,
  `senha` int(8) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `usuario`
--

INSERT INTO `usuario` (`id_usuario`, `email`, `senha`) VALUES
(2, 'JOAO@HOTMAIL.COM', 12345678),
(3, 'LUCAS@HOTMAIL.COM', 102030),
(5, 'TESTE@HOTMAIL.COM', 1234),
(6, 'TESTE2@GMAIL.COM', 1020),
(7, 'LEONARDO@HOTMAIL.COM', 123456),
(8, 'MARIO@GMAIL.COM', 12345),
(9, 'TESTE@HOTMAIL.COM', 12345),
(10, 'MARCOS@HOTMAIL.COM', 54321),
(11, 'ELTON@HOTMAIL.COM', 12356),
(13, 'RAFA@HOTMAIL.COM', 1234);

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `cliente`
--
ALTER TABLE `cliente`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `funcionario`
--
ALTER TABLE `funcionario`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `produto`
--
ALTER TABLE `produto`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `usuario`
--
ALTER TABLE `usuario`
  ADD UNIQUE KEY `id_usuario` (`id_usuario`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `cliente`
--
ALTER TABLE `cliente`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de tabela `funcionario`
--
ALTER TABLE `funcionario`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT de tabela `produto`
--
ALTER TABLE `produto`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Restrições para despejos de tabelas
--

--
-- Limitadores para a tabela `usuario`
--
ALTER TABLE `usuario`
  ADD CONSTRAINT `usuario_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `funcionario` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
